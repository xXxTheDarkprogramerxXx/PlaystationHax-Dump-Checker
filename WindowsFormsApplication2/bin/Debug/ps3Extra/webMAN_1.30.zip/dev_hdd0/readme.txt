For best results you will have to make the plugin load at COBRA7 system boot:

    * Copy webftp_server.sprx to /dev_hdd0
    * Create a text file boot_plugins.txt and upload it to your PS3 in /dev_hdd0
    * Edit your category_game.xml (/dev_blind/vsh/resource/explore/xmb/category_game.xml) - the only change in this xml is to add one line. If you're scared to do that, here is my category_game.xml - this is from COBRA7-ROGERO with only added "My Game" folder in the "GAME" column: deanbg.com/category_game.zip (unzip the file)


<Query class="type:x-xmb/folder-pixmap" key="xmb_app3"     attr="xmb_app3" src="xmb://localhost/dev_hdd0/xmlhost/game_plugin/fb.xml#seg_fb"/>

This is all you need:

1) webftp_server.sprx (in /dev_hdd0): deanbg.com/webftp_server.sprx
2) boot_plugins.txt (in /dev_hdd0): deanbg.com/boot_plugins.zip (unzip the file)
3) category_game.xml (in /dev_blind/vsh/resource/explore/xmb/): deanbg.com/category_game.zip (unzip the file)
4) COBRA7-Rogero firmware
5) PS3 browser set in Tools -> Confirmation on Browser Close -> "OFF"

====================================

To grant NTFS access to webMAN you will have to use prepNTFS. You can either install the prepNTFS.pkg application or launch prepNTFS.self from multiMAN's mmOS. In either case prepNTFS will scan all connected USB drives and will generate data for all PS3ISO/BDISO/DVDISO entries in /dev_hdd0/tmp/wmtmp. NTFS entries have .ntfs[PS3ISO] / .ntfs[BDISO] / .ntfs[DVDISO] suffixes - 64KB each - this is what webMAN will use to mount the games/videos. For covers/title-names to appear properly you will have to mount the PS3 game at least once, so webMAN can cache the PNG and SFO for the title.

You have to use prepNTFS if you add new content to your NTFS formatted USB HDDs. Do not forget to use [Refresh XML] / [Refresh HTML] to refresh webMAN's data.

====================================

webMAN 1.24 (90KB)
http://www.deanbg.com/webftp_server.sprx

webMAN 1.24 CCAPI (90KB)
http://www.deanbg.com/webftp_server_ccapi.sprx

====================================

prepNTFS 1.0 (PKG) (297KB)
http://www.deanbg.com/prepNTFS.pkg

prepNTFS 1.0 (SELF) (273KB)
http://www.deanbg.com/prepNTFS.self

webMAN 1.24 source with prepNTFS.self, prepNTFS.pkg, webftp_server.sprx and webftp_server_ccapi.sprx (888KB)
http://www.deanbg.com/webMAN_1.24.zip


====================================

In webMAN's [Setup] screen you'll find these download links at the bottom of the page (under [SAVE]):

* prepNTFS - Prepare NTFS drives for webMAN access
* webMAN (LATEST) - Latest version of webMAN
* webMAN (CCAPI) - ControlConsoleAPI compatible version of webMAN

====================================

There you are... in just 90KB plugin you have:

- FTP server
- WWW server
- NETISO support for network loading of PS3 games in ISO and folder format, DVD videos in ISO format, Blu-ray movies in ISO format, PS1 and PSP games
- NTFS support for PS3 games in ISO format, Blu-ray movies in ISO format and DVD Video in ISO format
- Dynamic Fan Control
- PAD shortcuts: [SELECT]+L1 (PREV TITLE), [SELECT]+R1 (NEXT TITLE), [L3]+[R2]+[X] (SHUTDOWN), [L3]+[R2]+[O] (RESTART)

====================================

Thanks to:

* Cobra Developer for COBRA7 CORE, ntfs_ext_iso and rawseciso
* Estwald for the ntfs library port and fan control payload
* @aldostools for tests and suggestions
* @twisted3313 for suggesting ccappi support

====================================